﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class MyTile : MonoBehaviour
{
    public enum TileType { Ground, Wall }
    public TileType typus;

    public MyTile() { typus = TileType.Wall; }
    public MyTile(TileType Typus) { typus = Typus; }
}
