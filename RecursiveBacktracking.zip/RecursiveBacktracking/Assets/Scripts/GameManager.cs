﻿using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField] private MyTile[,] levelTiles;

    private Stack<Vector2Int> positions;

    private GameObject Level;

    private Vector2Int currentPosition;

    public int mapSize;
    public int stepLength;

    void Start()
    {
        Level = new GameObject("Level");
        positions = new Stack<Vector2Int>();

        CreateLevel(mapSize);

        MakeMaze();
    }

    private void CreateLevel(int size)
    {
        levelTiles = new MyTile[size, size];

        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                GameObject temp = GameObject.CreatePrimitive(PrimitiveType.Cube);
                temp.transform.position = new Vector3(i, 0, j);
                temp.transform.SetParent(Level.transform);
                levelTiles[i, j] = temp.AddComponent<MyTile>();

                // make frame as ground so we do not dig there
                if (i == 0 || j == 0 || i == size - 1 || j == size - 1)
                {
                    levelTiles[i, j].typus = MyTile.TileType.Ground;
                }
            }
        }
    }

    private void MakeMaze()
    {
        currentPosition = GetRandomStartPosition();
        SetTileType(currentPosition, MyTile.TileType.Ground);
        positions.Push(currentPosition);

        while (positions.Count > 0)
        {
            Vector2Int digDirection = GetRandomDirection(currentPosition);

            while (digDirection == Vector2Int.zero)
            {
                positions.Pop();

                if (positions.Count == 0)
                    return;

                currentPosition = positions.Peek();

                digDirection = GetRandomDirection(currentPosition);
            }

            currentPosition = DigInDirection(currentPosition, digDirection, stepLength);
            positions.Push(currentPosition);
        }
    }

    // Zufälligen Startpunkt wählen
    private Vector2Int GetRandomStartPosition()
    {
        int startX = Random.Range(1, mapSize - 1);
        int startY = Random.Range(1, mapSize - 1);

        startX = startX % 2 == 0 ? startX - 1 : startX;
        startY = startY % 2 == 0 ? startY - 1 : startY;

        Vector2Int startPos = new Vector2Int(startX, startY);
        //Debug.Log($"StartPos: {startPos}");

        return startPos;
    }

    private void SetTileType(Vector2Int position, MyTile.TileType tiletype)
    {
        try
        {
            levelTiles[position.x, position.y].typus = tiletype;
            if (tiletype == MyTile.TileType.Ground)
            {
                Destroy(levelTiles[position.x, position.y].gameObject);
            }
        }
        catch (System.IndexOutOfRangeException e)
        {
            Debug.LogWarning($"{e.Message}: position = {position}");
        }

    }

    private MyTile GetNeighbor(Vector2Int position, Vector2Int direction)
    {
        MyTile temp = null;

        try
        {
            temp = levelTiles[position.x + stepLength * direction.x, position.y + stepLength * direction.y];

            if (temp.typus == MyTile.TileType.Ground)
            {
                temp = null;
            }
        }
        catch (System.IndexOutOfRangeException e)
        {
            Debug.LogWarning(e.Message);
        }

        return temp;
    }

    // zufällige Richtung graben
    private Vector2Int GetRandomDirection(Vector2Int position)
    {
        List<Vector2Int> directions = new List<Vector2Int>();

        if (GetNeighbor(position, Vector2Int.right) != null)
        {
            directions.Add(Vector2Int.right);
        }
        if (GetNeighbor(position, Vector2Int.left) != null)
        {
            directions.Add(Vector2Int.left);
        }
        if (GetNeighbor(position, Vector2Int.down) != null)
        {
            directions.Add(Vector2Int.down);
        }
        if (GetNeighbor(position, Vector2Int.up) != null)
        {
            directions.Add(Vector2Int.up);
        }

        // wenn sackgasse, Position vom Stack nehmen
        if (directions.Count == 0)
        {
            // Vector2Int.zero = keine valide Richtung
            // keine Nachbarn gefunden
            return Vector2Int.zero;
        }
        else
        {
            return directions[Random.Range(0, directions.Count)];
        }
    }

    private Vector2Int DigInDirection(Vector2Int position, Vector2Int direction, int stepLength)
    {
        for (int i = 1; i <= stepLength; i++)
        {
            SetTileType(position + i * direction, MyTile.TileType.Ground);
        }

        return position + stepLength * direction;
    }
}
